<?php
define('HOST' , 'localhost');
define('USER','root');
define('PASS','');
define('BASE','cadastros');

$conn = new mysqli(HOST,USER,PASS,BASE);
